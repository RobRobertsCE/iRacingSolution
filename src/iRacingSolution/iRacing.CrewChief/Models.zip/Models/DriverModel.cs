﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace iRacing.CrewChief.Models
{
    public class DriverModel
    {
        public long CarIdx { get; set; }
        public string UserName { get; set; }
        public string AbbrevName { get; set; }
        public string Initials { get; set; }
        public long UserID { get; set; }
        public long TeamID { get; set; }
        public string TeamName { get; set; }
        public string CarNumber { get; set; }
        public long CarNumberRaw { get; set; }
        public string CarPath { get; set; }
        public long CarClassID { get; set; }
        public long CarID { get; set; }
        public string CarScreenName { get; set; }
        public string CarScreenNameShort { get; set; }
        public string CarClassShortName { get; set; }
        public long CarClassRelSpeed { get; set; }
        public long CarClassLicenseLevel { get; set; }
        public string CarClassMaxFuelPct { get; set; }
        public string CarClassWeightPenalty { get; set; }
        public string CarClassColor { get; set; }
        public long IRating { get; set; }
        public long LicLevel { get; set; }
        public long LicSubLevel { get; set; }
        public string LicString { get; set; }
        public string LicColor { get; set; }
        public long IsSpectator { get; set; }
        public string CarDesignStr { get; set; }
        public string HelmetDesignStr { get; set; }
        public string SuitDesignStr { get; set; }
        public string CarNumberDesignStr { get; set; }
        public long CarSponsor_1 { get; set; }
        public long CarSponsor_2 { get; set; }
        public string ClubName { get; set; }
        public string DivisionName { get; set; }

        public static DriverModel FromDataSample(iRacingSDK.SessionData._DriverInfo._Drivers dataSample)
        {
            var serialized = JsonConvert.SerializeObject(dataSample);
            return JsonConvert.DeserializeObject<DriverModel>(serialized);
        }
       
    }
    //static class DriverExtensions
    //{
    //    public static int MaxLength(this SessionData._DriverInfo._Drivers[] self)
    //    {
    //        return (int)self.Where(d => d.CarNumberRaw > 0).Max(d => d.CarIdx) + 1;
    //    }
    //}
    //public class DriverInfoModel
    //{
    //    public long DriverCarIdx { get; set; }
    //    public double DriverHeadPosX { get; set; }
    //    public double DriverHeadPosY { get; set; }
    //    public double DriverHeadPosZ { get; set; }
    //    public double DriverCarIdleRPM { get; set; }
    //    public double DriverCarRedLine { get; set; }
    //    public double DriverCarFuelKgPerLtr { get; set; }
    //    public double DriverCarFuelMaxLtr { get; set; }
    //    public double DriverCarMaxFuelPct { get; set; }
    //    public double DriverCarSLFirstRPM { get; set; }
    //    public double DriverCarSLShiftRPM { get; set; }
    //    public double DriverCarSLLastRPM { get; set; }
    //    public double DriverCarSLBlinkRPM { get; set; }
    //    public double DriverPitTrkPct { get; set; }
    //    public double DriverCarEstLapTime { get; set; }
    //    public string DriverSetupName { get; set; }
    //    public long DriverSetupIsModified { get; set; }
    //    public string DriverSetupLoadTypeName { get; set; }
    //    public long DriverSetupPassedTech { get; set; }
    //}

    //public partial class x_DriverInfo
    //{
    //    public long DriverCarIdx { get; set; }
    //    public double DriverHeadPosX { get; set; }
    //    public double DriverHeadPosY { get; set; }
    //    public double DriverHeadPosZ { get; set; }
    //    public double DriverCarIdleRPM { get; set; }
    //    public double DriverCarRedLine { get; set; }
    //    public double DriverCarFuelKgPerLtr { get; set; }
    //    public double DriverCarFuelMaxLtr { get; set; }
    //    public double DriverCarMaxFuelPct { get; set; }
    //    public double DriverCarSLFirstRPM { get; set; }
    //    public double DriverCarSLShiftRPM { get; set; }
    //    public double DriverCarSLLastRPM { get; set; }
    //    public double DriverCarSLBlinkRPM { get; set; }
    //    public double DriverPitTrkPct { get; set; }
    //    public double DriverCarEstLapTime { get; set; }
    //    public string DriverSetupName { get; set; }
    //    public long DriverSetupIsModified { get; set; }
    //    public string DriverSetupLoadTypeName { get; set; }
    //    public long DriverSetupPassedTech { get; set; }
 
    //    public partial class x_Drivers
    //    {
    //        public long CarIdx { get; set; }
    //        public string UserName { get; set; }
    //        public string AbbrevName { get; set; }
    //        public string Initials { get; set; }
    //        public long UserID { get; set; }
    //        public long TeamID { get; set; }
    //        public string TeamName { get; set; }
    //        public string CarNumber { get; set; }
    //        public long CarNumberRaw { get; set; }
    //        public string CarPath { get; set; }
    //        public long CarClassID { get; set; }
    //        public long CarID { get; set; }
    //        public string CarScreenName { get; set; }
    //        public string CarScreenNameShort { get; set; }
    //        public string CarClassShortName { get; set; }
    //        public long CarClassRelSpeed { get; set; }
    //        public long CarClassLicenseLevel { get; set; }
    //        public string CarClassMaxFuelPct { get; set; }
    //        public string CarClassWeightPenalty { get; set; }
    //        public string CarClassColor { get; set; }
    //        public long IRating { get; set; }
    //        public long LicLevel { get; set; }
    //        public long LicSubLevel { get; set; }
    //        public string LicString { get; set; }
    //        public string LicColor { get; set; }
    //        public long IsSpectator { get; set; }
    //        public string CarDesignStr { get; set; }
    //        public string HelmetDesignStr { get; set; }
    //        public string SuitDesignStr { get; set; }
    //        public string CarNumberDesignStr { get; set; }
    //        public long CarSponsor_1 { get; set; }
    //        public long CarSponsor_2 { get; set; }
    //        public string ClubName { get; set; }
    //        public string DivisionName { get; set; }
    //    }
    //}
}
