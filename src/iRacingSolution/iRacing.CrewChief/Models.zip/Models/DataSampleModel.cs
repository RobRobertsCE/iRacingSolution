﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using iRacingSDK;

namespace iRacing.CrewChief.Models
{
    public class DataSampleModel //: iRacingSDK.DataSample
    {
        new public bool IsConnected { get; set; }


        private SessionDataModel sessionData;
        new public SessionDataModel SessionData
        {
            get
            {
                return sessionData;
            }
            set
            {
                sessionData = value;
            }
        }

        private TelemetryModel telemetry;
        new public TelemetryModel Telemetry
        {
            get
            {
                return telemetry;
            }
            set
            {
                telemetry = value;
            }
        }

        public DataSampleModel()
        {
            IsConnected = true;
        }
    }
}
